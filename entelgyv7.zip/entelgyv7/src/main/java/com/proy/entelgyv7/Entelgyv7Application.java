package com.proy.entelgyv7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Entelgyv7Application {

	public static void main(String[] args) {
		SpringApplication.run(Entelgyv7Application.class, args);
	}

}
