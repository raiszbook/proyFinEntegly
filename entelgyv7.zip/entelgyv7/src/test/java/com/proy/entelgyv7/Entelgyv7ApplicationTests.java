package com.proy.entelgyv7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Entelgyv7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
